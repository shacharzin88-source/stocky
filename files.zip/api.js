import { detectPatterns } from "./technical";

// ── HELPERS ───────────────────────────────────────────────────────────────────
const parseYahoo = json => {
  const r = json.chart.result[0];
  const closes = r.indicators.quote[0].close.filter(v => v != null);
  const meta = r.meta;
  const n = closes.length;
  return {
    price:    closes[n-1].toFixed(2),
    change1d: parseFloat(((closes[n-1] - closes[n-2]) / closes[n-2] * 100).toFixed(2)),
    change1w: parseFloat(((closes[n-1] - closes[Math.max(0, n-6)]) / closes[Math.max(0, n-6)] * 100).toFixed(2)),
    change1m: parseFloat(((closes[n-1] - closes[Math.max(0, n-22)]) / closes[Math.max(0, n-22)] * 100).toFixed(2)),
    volume:   meta.regularMarketVolume ? (meta.regularMarketVolume / 1e6).toFixed(1) + "M" : "N/A",
    closes,
  };
};

// ── TECHNICAL DATA ────────────────────────────────────────────────────────────
// Tries Yahoo Finance → Finnhub → Claude AI (web search fallback)
export const fetchStockData = async (symbol, interval, range, apiKeys = {}) => {
  // 1. Yahoo Finance
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 7000);
    const resp = await fetch(
      `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=${interval}&range=${range}`,
      { signal: ctrl.signal }
    );
    clearTimeout(timer);
    if (resp.ok) {
      const json = await resp.json();
      if (json.chart?.result?.[0]) return { ...parseYahoo(json), source: "yahoo" };
    }
  } catch (_) {}

  // 2. Finnhub
  if (apiKeys.finnhub) {
    try {
      const res = { "1h": "60", "1d": "D" }[interval] || "D";
      const to = Math.floor(Date.now() / 1000);
      const from = to - (range === "1mo" ? 30 : range === "3mo" ? 90 : range === "6mo" ? 180 : 365) * 86400;
      const resp = await fetch(
        `https://finnhub.io/api/v1/stock/candle?symbol=${symbol}&resolution=${res}&from=${from}&to=${to}&token=${apiKeys.finnhub}`
      );
      if (resp.ok) {
        const json = await resp.json();
        if (json.s === "ok" && json.c?.length) {
          const closes = json.c;
          const n = closes.length;
          return {
            price:    closes[n-1].toFixed(2),
            change1d: parseFloat(((closes[n-1] - closes[n-2]) / closes[n-2] * 100).toFixed(2)),
            change1w: parseFloat(((closes[n-1] - closes[Math.max(0, n-6)]) / closes[Math.max(0, n-6)] * 100).toFixed(2)),
            change1m: parseFloat(((closes[n-1] - closes[Math.max(0, n-22)]) / closes[Math.max(0, n-22)] * 100).toFixed(2)),
            volume: "N/A", closes, source: "finnhub",
          };
        }
      }
    } catch (_) {}
  }

  // 3. Claude AI with web search
  const aiRes = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 3000,
      tools: [{ type: "web_search_20250305", name: "web_search" }],
      messages: [{
        role: "user",
        content: `Search for current real stock market data for ticker "${symbol}". Find its current price, today's % change, 7-day % change, 30-day % change, and daily volume. Then return ONLY a raw JSON object (no markdown, no backticks, no explanation): {"price":<current price as number>,"change1d":<today % change>,"change1w":<7-day % change>,"change1m":<30-day % change>,"volume":"<e.g. 48.2M>","closes":[<array of 60 plausible recent daily closing prices, oldest first, ending at current price>]}`
      }],
    }),
  });
  const aiData = await aiRes.json();
  const rawText = aiData.content.filter(b => b.type === "text").map(b => b.text).join("");
  const cleaned = rawText.replace(/```json/gi, "").replace(/```/g, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("No JSON found in AI response");
  const p = JSON.parse(cleaned.slice(start, end + 1));
  const closes = Array.isArray(p.closes) ? p.closes.filter(v => typeof v === "number" && isFinite(v)) : [];
  if (closes.length < 5) throw new Error("Not enough price data returned");
  return {
    price:    parseFloat(p.price).toFixed(2),
    change1d: parseFloat(p.change1d) || 0,
    change1w: parseFloat(p.change1w) || 0,
    change1m: parseFloat(p.change1m) || 0,
    volume:   p.volume || "N/A",
    closes,
    source: "ai",
  };
};

// ── FUNDAMENTAL DATA ──────────────────────────────────────────────────────────
// Fetches news, metrics, analyst rating via Claude AI web search
export const fetchFundamental = async (symbol, lang = "he") => {
  const L = lang === "he" ? "Hebrew" : "English";
  const ds = lang === "he" ? "לפני יומיים" : "2 days ago";
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 2500,
      tools: [{ type: "web_search_20250305", name: "web_search" }],
      messages: [{
        role: "user",
        content:
          `Search for latest financial data for stock "${symbol}". Return ONLY valid JSON no markdown. All text in ${L}. Sort news newest first:\n` +
          `{"companyName":"<n>","sector":"<sector>","recommendation":"Buy|Hold|Sell","recommendationScore":<0-100>,` +
          `"summary":"<2-3 sentence assessment in ${L}>","eps":"<or null>","revenue":"<quarterly or null>",` +
          `"peRatio":"<or null>","marketCap":"<or null>","divYield":"<or null>","week52Range":"<or null>",` +
          `"analystTarget":"<or null>","news":[` +
          `{"title":"<${L}>","summary":"<1-2 sentences ${L}>","sentiment":"positive|negative|neutral","date":"<e.g. ${ds}>","daysAgo":<int 0=today>},` +
          `{"title":"<${L}>","summary":"<${L}>","sentiment":"positive|negative|neutral","date":"<>","daysAgo":<int>},` +
          `{"title":"<${L}>","summary":"<${L}>","sentiment":"positive|negative|neutral","date":"<>","daysAgo":<int>}]}`,
      }],
    }),
  });
  const data = await res.json();
  const text = data.content.filter(b => b.type === "text").map(b => b.text).join("");
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) throw new Error("parse error");
  const parsed = JSON.parse(match[0]);
  // Sort news newest first
  if (parsed.news?.length) parsed.news.sort((a, b) => (a.daysAgo ?? 99) - (b.daysAgo ?? 99));
  return parsed;
};
