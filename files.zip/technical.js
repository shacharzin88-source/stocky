// ── TECHNICAL ANALYSIS UTILITIES ─────────────────────────────────────────────

export const calcRSI = (c, p = 14) => {
  if (c.length < p + 1) return 50;
  let g = 0, l = 0;
  for (let i = c.length - p; i < c.length; i++) {
    const d = c[i] - c[i - 1];
    if (d > 0) g += d; else l -= d;
  }
  return parseFloat((100 - 100 / (1 + (g / p) / ((l / p) || 0.001))).toFixed(1));
};

export const calcMA = (c, p) =>
  c.map((_, i) =>
    i < p - 1 ? null : c.slice(i - p + 1, i + 1).reduce((a, b) => a + b, 0) / p
  );

// Detect all patterns on a given price window
export const detectOnWindow = win => {
  const patterns = [], wn = win.length;
  if (wn < 10) return patterns;
  const sp = Math.max(3, Math.floor(wn * 0.1));

  // Golden Cross
  if (wn >= 60) {
    const p1 = Math.min(10, Math.floor(wn * 0.08)), p2 = Math.min(20, Math.floor(wn * 0.16));
    const ma1 = calcMA(win, p1), ma2 = calcMA(win, p2);
    for (let i = wn - 8; i < wn; i++) {
      if (ma1[i] && ma2[i] && ma1[i-1] && ma2[i-1] && ma1[i] > ma2[i] && ma1[i-1] <= ma2[i-1]) {
        patterns.push({ name: "Golden Cross", confidence: 85,
          chartData: { type: "ma_cross", closes: win.slice(-60), ma50: ma1.slice(-60), ma200: ma2.slice(-60) } });
        break;
      }
    }
  }

  // Head & Shoulders
  if (wn >= 20) {
    const peaks = [];
    for (let i = 2; i < wn - 2; i++) {
      if (win[i] > win[i-1] && win[i] > win[i-2] && win[i] > win[i+1] && win[i] > win[i+2])
        peaks.push({ i, v: win[i] });
    }
    for (let pi = 0; pi < peaks.length - 2; pi++) {
      const [p0, p1, p2] = [peaks[pi], peaks[pi+1], peaks[pi+2]];
      if (p1.v > p0.v * 1.01 && p1.v > p2.v * 1.01 &&
          Math.abs(p0.v - p2.v) / p1.v < 0.07 &&
          (p1.i - p0.i) >= sp && (p2.i - p1.i) >= sp && win[wn-1] < p2.v) {
        const t1 = Math.min(...win.slice(p0.i, p1.i + 1));
        const t2 = Math.min(...win.slice(p1.i, p2.i + 1));
        patterns.push({ name: "Head & Shoulders", confidence: 70,
          chartData: { type: "hs", closes: win, peaks: [p0, p1, p2], neckline: (t1 + t2) / 2 } });
        break;
      }
    }
  }

  // Double Bottom
  if (wn >= 15) {
    const minima = [];
    for (let i = 2; i < wn - 2; i++) {
      if (win[i] < win[i-1] && win[i] < win[i-2] && win[i] < win[i+1] && win[i] < win[i+2])
        minima.push({ i, v: win[i] });
    }
    for (let mi = 0; mi < minima.length - 1; mi++) {
      const [m0, m1] = [minima[mi], minima[mi+1]];
      if (m1.i - m0.i >= sp && Math.abs(m0.v - m1.v) / ((m0.v + m1.v) / 2) < 0.035) {
        const peak = Math.max(...win.slice(m0.i, m1.i + 1));
        if (win[wn-1] > peak * 0.97) {
          patterns.push({ name: "Double Bottom", confidence: 74,
            chartData: { type: "double_bottom", closes: win, idx1: m0.i, idx2: m1.i, support: (m0.v + m1.v) / 2 } });
          break;
        }
      }
    }
  }

  // Breakout
  if (wn >= 8) {
    const res = Math.max(...win.slice(0, wn - 2));
    if (win[wn-1] > res * 1.01 && win[wn-2] > res * 0.995)
      patterns.push({ name: "Breakout", confidence: 78,
        chartData: { type: "breakout", closes: win, resistance: res, breakPct: ((win[wn-1] - res) / res * 100).toFixed(1) } });
  }

  // Flag
  if (wn >= 12) {
    const fe = Math.floor(wn * 0.65), pole = win.slice(0, fe), flag = win.slice(fe);
    const rise = (Math.max(...pole) - pole[0]) / pole[0];
    const avg = flag.reduce((a, b) => a + b, 0) / flag.length;
    if (rise > 0.04 && (Math.max(...flag) - Math.min(...flag)) / avg < 0.03 && flag[flag.length-1] < flag[0])
      patterns.push({ name: "Flag", confidence: 73,
        chartData: { type: "flag", closes: win, flagStart: fe, poleRise: (rise * 100).toFixed(1) } });
  }

  // RSI Divergence
  if (wn >= 20) {
    const peaks = [];
    for (let i = 1; i < wn - 1; i++) {
      if (win[i] > win[i-1] && win[i] > win[i+1]) peaks.push({ i, v: win[i] });
    }
    if (peaks.length >= 2) {
      const [pp1, pp2] = [peaks[peaks.length-2], peaks[peaks.length-1]];
      if (pp2.v > pp1.v * 1.005) {
        const r1 = calcRSI(win.slice(0, pp1.i + 1));
        const r2 = calcRSI(win.slice(0, pp2.i + 1));
        if (r2 < r1 - 3)
          patterns.push({ name: "RSI Divergence", confidence: 69,
            chartData: { type: "rsi_div", closes: win, peakIdx1: pp1.i, peakIdx2: pp2.i,
              rsi1: parseFloat(r1.toFixed(1)), rsi2: parseFloat(r2.toFixed(1)) } });
      }
    }
  }

  return patterns;
};

// Main entry point — auto mode uses correct window per pattern type
export const detectPatterns = (closes, customBars = null) => {
  if (!closes || closes.length < 10) return [];
  if (customBars) return detectOnWindow(closes.slice(-Math.min(customBars, closes.length)));
  const n = closes.length, all = [];
  all.push(...detectOnWindow(closes.slice(-Math.min(90, n))).filter(p => p.name !== "Golden Cross"));
  if (n >= 205) {
    const gc = detectOnWindow(closes);
    const f = gc.find(p => p.name === "Golden Cross");
    if (f) all.push(f);
  }
  return all.slice(0, 4);
};
